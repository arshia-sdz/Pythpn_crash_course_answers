from pathlib import Path
path = Path('learning_python.txt')

contents = path.read_text()
learning_python = ''

for line in contents.splitlines():
    learning_python += line

print(learning_python)
print(7*'\n')

learning_python = learning_python.replace("python", 'C')
learning_python = learning_python.replace("Python", 'C')
print(learning_python)

print("Hello World!")
