from pathlib import Path

fname = input("First Name: ")
lname = input("Last Name: ")

contents = f"First Name: {fname.title()}\n" 
contents += f"Last Name: {lname.title()}"

path = Path('guest.txt')
path.write_text(contents)
