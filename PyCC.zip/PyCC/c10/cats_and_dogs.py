from pathlib import Path

reading_files = []

def dogs_and_cats(path):
	
	try:
		contents = path.read_text(encoding='utf-8')

	except FileNotFoundError:
		pass

	else:
		words = contents.split()
		for x in words:
			reading_files.append(x)


filenames = ['cats.txt','dogs.txt']	


for filename in filenames:
	path = Path(filename)
	dogs_and_cats(path)


for reading_file in reading_files:
	print(reading_file)
