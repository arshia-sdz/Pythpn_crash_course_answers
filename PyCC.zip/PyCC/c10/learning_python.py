# First Way
"""
from pathlib import Path
path = Path('learning_python.txt')

contents = path.read_text()
print(contents)
"""

# Second Way
from pathlib import Path
path = Path('learning_python.txt')

contents = path.read_text()
lines = contents.splitlines()

learning_python = ''
for line in lines:
    learning_python += line
    print(learning_python)

print(len(learning_python))
