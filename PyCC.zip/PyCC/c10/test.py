from pathlib import Path

contents = ""

path = Path('dogs.txt')
path.write_text(contents)
