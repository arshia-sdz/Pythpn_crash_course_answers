from pathlib import Path
print("Enter the name of your books. If you ever want to stop write <quit>.")

contents = ''
while True:
	book_name = input("Enter your book's name: ")
	if book_name == 'quit':
		break
	else:
		contents += book_name.title() + '\n'

path = Path('guest_book.txt')
path.write_text(contents)