def fav_book(book):
	print(f"My favorite book is {book.title()}!")

fav_book('harry potter')
