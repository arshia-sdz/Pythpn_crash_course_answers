def message():
	print("Hey Yo! I am learning functions in this chapter!")

message()
