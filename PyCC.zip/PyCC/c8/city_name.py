def city_country(city, country):
	print(f"{city.title()}, {country.title()}")

city_country(city = 'beijing', country = 'china')
city_country(country = 'brazil', city = 'são paulo')
city_country(city = 'tehran', country = 'iran')
