def make_car(manufacturer, model, **information):
	information['brand'] = manufacturer
	information['model'] = model
	return information

car = make_car('subaru', 'outback', color='blue', tow_package=True)
print(car)
