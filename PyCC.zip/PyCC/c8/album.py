"""
# Simple version
def make_album(artist, album_name):
	album = {}
	album["artist"] = artist
	album["album's name"] = album_name
	print(album)

make_album(artist = 'sia', album_name = 'this is acting')
make_album(artist = 'avicii', album_name = 'true')
make_album(artist = 'eminem', album_name = 'recovery')
"""


# This version doesn't work!
def make_album(artist, album_name, number_of_songs = None):
	if number_of_songs:		# If any information of the number of songs!
		album = {
			'artist': artist,
			'name': album_name,
			'songs': number_of_songs
			}

	else:					# If No information of the number of songs!
		album = {
			'artist': artist,
			'name': album_name
			}

	print(album)


make_album(artist = 'sia', album_name = 'this is acting')
make_album(artist = 'avicii', album_name = 'true')
make_album(artist = 'eminem', album_name = 'recovery')
make_album(artist = 'adele', album_name = '21', number_of_songs = 12)


''' 
For some quite strange reason when I have used return album instead of 
print(album) I couldn't get any data!
'''

while True:
	
	print("\nEnter the Artist's name and his/her album!\n",
		"If you don't know how many songs are in the album, you can just skip it!\n",
		"If you want to quit write 'q' any time!"
		)

	artist_name = input("Artist's name: ")
	if artist_name == 'q':
		break

	album = input("Album's name: ")
	if artist_name == 'q':
		break

	songs_q = input("Number of songs: ")
	if artist_name == 'q':
		break

	make_album(artist = artist_name, album_name = album, number_of_songs = songs_q)
