def order(*sandwitches):
    for sandwitch in sandwitches:
        print(f"\nPreparing {sandwitch}!\n")

order("Grilled Cheese", "Veggie Delight", "Caprese Sandwich")
order("Chicken Club", "Turkey Avocado", "BLT")
order("Hummus and Veggie", "Avocado and Tomato", "Vegan Chickpea Salad")
