'''
from priniting_functions import print_models
from priniting_functions import show_completed_models

unprinted_designs = ['phone case', 'robot pendant', 'dodecahedron']
completed_models = []

print_models(unprinted_designs, completed_models)
show_completed_models(completed_models)
'''

'''
from priniting_functions import *

unprinted_designs = ['phone case', 'robot pendant', 'dodecahedron']
completed_models = []

print_models(unprinted_designs, completed_models)
show_completed_models(completed_models)
'''

'''
import priniting_functions

unprinted_designs = ['phone case', 'robot pendant', 'dodecahedron']
completed_models = []

priniting_functions.print_models(unprinted_designs, completed_models)
priniting_functions.show_completed_models(completed_models)
'''

'''
import priniting_functions as pf

unprinted_designs = ['phone case', 'robot pendant', 'dodecahedron']
completed_models = []

pf.print_models(unprinted_designs, completed_models)
pf.show_completed_models(completed_models)
'''

'''
from priniting_functions import print_models as pm
from priniting_functions import show_completed_models as scm

unprinted_designs = ['phone case', 'robot pendant', 'dodecahedron']
completed_models = []

pm(unprinted_designs, completed_models)
scm(completed_models)
'''
