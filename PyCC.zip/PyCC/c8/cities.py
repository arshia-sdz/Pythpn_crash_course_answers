def describe_city(city, country = 'united states'):
	print(f"{city.title()} is located in {country.title()}!")

describe_city(city = 'philadelphia')
describe_city(city = 'california')
describe_city(city = 'amsterdam' , country = 'netherlands')
