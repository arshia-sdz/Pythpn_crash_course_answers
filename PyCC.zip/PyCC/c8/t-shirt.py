"""
# Exercise 8.3
def make_shirt(size, printed_message):
	print(f"Size: {size}")
	print(f"Message you wanted to print: '{printed_message}'!\n")

# Positional Calling
make_shirt('XL', 'I love IB!')
# Keyword Argument calling
make_shirt(size = 'XL', printed_message = 'I Love IB!')
"""


# Exercise 8.4
def make_shirt(printed_message = 'I love Python', size = 'Large'):
	print(f"Size: {size}")
	print(f"Message you wanted to print: '{printed_message}'!\n")

# Keyword Argument calling
make_shirt(size = 'medium')
make_shirt(size = 'large')
make_shirt(printed_message = 'I Love NYC!')

""" I am more convenient working with this type of calling 
because the chance that I make an error is less."""

