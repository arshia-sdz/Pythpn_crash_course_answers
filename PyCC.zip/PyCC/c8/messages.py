"""
# 8.9
messages = ['i love python', 'hello world!', 'i am learning functions!']

def show_messages(messages):
	for message in messages:
		print(message.title())

show_messages(messages)
"""

"""
# 8.10
# Copying code from 8.9
listed_unsent_messages = [
	'i love python',
	'hello world!',
	'i am learning functions!'
	]

listed_sent_messages = []

# From Last Excercise 
'''
def show_messages(messages):
	for message in messages:
		print(message.title())

show_messages(listed_unsent_messages)
'''

def printed_messages(unsent_messages, sent_messages):
	while unsent_messages:
		current_message = unsent_messages.pop()
		print(f"Printing '{current_message.title()}!'\n")
		sent_messages.append(current_message)
	print(unsent_messages)
	print(sent_messages)

printed_messages(listed_unsent_messages, listed_sent_messages)

print(listed_unsent_messages)
print(listed_sent_messages)
"""

# 8.11
# Copying code from 8.9
listed_unsent_messages = [
	'i love python',
	'hello world!',
	'i am learning functions!'
	]

listed_sent_messages = []

# From Last Excercise 
'''
def show_messages(messages):
	for message in messages:
		print(message.title())

show_messages(listed_unsent_messages)
'''

def printed_messages(unsent_messages, sent_messages):
	while unsent_messages:
		current_message = unsent_messages.pop()
		print(f"Printing '{current_message.title()}!'\n")
		sent_messages.append(current_message)
	print(unsent_messages)
	print(sent_messages)

printed_messages(listed_unsent_messages[:], listed_sent_messages)

print(listed_unsent_messages)
