# This only writes "Hello"
def greet_user():
	""" Display a simple greetong! """
	print('Hello!') 

# This will get input from the username and will print hello - user's input
def greet_user(username):
	print(f"Hello, {username.title()}!")

# Calling the Function
greet_user('alice')
