from restaurant import Restaurant

r1 = Restaurant('senso', 'italian')             #First instance
r1.describe_restaurant()
r1.open_restaurant()

r2 = Restaurant('taco bell', 'mexican')         #Second instance
r2.describe_restaurant()
r2.open_restaurant()

r3 = Restaurant('sakura', 'japanese')           #Third instance
r3.describe_restaurant()
r3.open_restaurant()
