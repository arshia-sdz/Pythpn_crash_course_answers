from random import randint


class Dice:
    def __init__(self, sides=6):
        self.sides = sides

    def roll_dice(self):
        if self.sides != 6:
            print(randint(1,self.sides))
        else:
            print(randint(1,6))


normal_dice = Dice()
n = 0
while True:
    if n < 10:
        normal_dice.roll_dice()
        n += 1
    else:
        break


special_dice = Dice(10)
n = 0
while True:
    if n < 10:
        special_dice.roll_dice()
        n += 1
    else:
        break


special_dice_2 = Dice(20)
n = 0
while True:
    if n < 10:
        special_dice.roll_dice()
        n += 1
    else:
        break