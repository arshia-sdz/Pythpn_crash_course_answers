from admin import Admin, Privileges
from users import User

admin_1 = Admin('arshia', 'sadeghzadeh')
admin_1.show_privileges()