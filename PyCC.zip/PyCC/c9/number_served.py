"""
class Restaurant:
    def __init__(self, name, cuisine_type):     #Initializing the attributes
        self.name = name
        self.cuisine_type = cuisine_type
        self.number_served = 0

    def describe_restaurant(self):              #Restaurant Information
        print(f"The name of the restaurant is {self.name.title()}!")
        print(f"{self.name.title()} makes {self.cuisine_type.title()} food!")

    def open_restaurant(self):                  #Opening the Restaurant
        print(f"{self.name.title()} is open!")
        print("\n")

r1 = Restaurant('senso', 'italian')             #First instance
print(r1.number_served)
r1.number_served = 3
print(r1.number_served)
"""

"""
class Restaurant:
    def __init__(self, name, cuisine_type):     #Initializing the attributes
        self.name = name
        self.cuisine_type = cuisine_type
        self.number_served = 0

    def describe_restaurant(self):              #Restaurant Information
        print(f"The name of the restaurant is {self.name.title()}!")
        print(f"{self.name.title()} makes {self.cuisine_type.title()} food!")

    def open_restaurant(self):                  #Opening the Restaurant
        print(f"{self.name.title()} is open!")

    def set_number_served(self):
        print(f"This restaurant has served {self.number_served} customers.")

r1 = Restaurant('senso', 'italian')  # First instance
r1.number_served = 3

r1.describe_restaurant()
r1.open_restaurant()
r1.set_number_served()
"""

"""
class Restaurant:
    def __init__(self, name, cuisine_type):     #Initializing the attributes
        self.name = name
        self.cuisine_type = cuisine_type
        self.number_served = 0

    def describe_restaurant(self):              #Restaurant Information
        print(f"The name of the restaurant is {self.name.title()}!")
        print(f"{self.name.title()} makes {self.cuisine_type.title()} food!")

    def open_restaurant(self):                  #Opening the Restaurant
        print(f"{self.name.title()} is open!")

    def set_number_served(self):
        print(f"This restaurant has served {self.number_served} customers.")

    def increment_number_served(self, ns):
        self.number_served += ns

r1 = Restaurant('senso', 'italian')  # First instance
r1.number_served = 3

r1.describe_restaurant()
r1.set_number_served()

r1.increment_number_served(7)
r1.set_number_served()
"""
