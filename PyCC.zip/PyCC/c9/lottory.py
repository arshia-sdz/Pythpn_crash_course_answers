# Libraries that we are going to use
from random import choice

# My Codes
"""
class Lottory:
    def __init__(self,
                 code = ('a', 'b', 'c', 'd', 'e'
                         ,1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
                 ):

        self.code = code
        self.w = choice(self.code)
        self.x = choice(self.code)
        self.y = choice(self.code)
        self.z = choice(self.code)
        self.winning_ticket = (self.w, self.x, self.y, self.z)

    def present_winner(self):
        print(f"Any one who has {self.winning_ticket} in their ticket wins the prize.")

lucky_person = Lottory()
lucky_person.present_winner()


trails = Lottory
my_ticket = ('a','b', 7, 9)

n = 0
while True:
    if trails == my_ticket:
        print(f"Number of tails done to get your ticket: {n}")
        break
    else:
        n += 1
"""

# My Codes After ChatGPT's Help
class Lottery:
    def __init__(self):
        self.code = ('a', 'b', 'c', 'd', 'e', 1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
        self.winning_ticket = self.generate_winning_ticket()

    def generate_winning_ticket(self):
        return tuple(choice(self.code) for _ in range(4))

    def present_winner(self):
        print(f"Any one who has {self.winning_ticket} in their ticket wins the prize.")


# Part 1: Announce the winning ticket
lottery = Lottery()
lottery.present_winner()

# Part 2: Find how many tries it takes for my_ticket to win
my_ticket = ('a', 'b', 7, 9)
n = 0  # Counter for attempts

while True:
    # Generate a new winning ticket for each attempt
    current_lottery = Lottery()
    n += 1
    if current_lottery.winning_ticket == my_ticket:
        print(f"Number of attempts needed to get your ticket: {n}")
        break
