class Restaurant:
    def __init__(self, name, cuisine_type):     #Initializing the attributes
        self.name = name
        self.cuisine_type = cuisine_type

    def describe_restaurant(self):              #Restaurant Information
        print(f"The name of the restaurant is {self.name.title()}!")
        print(f"{self.name.title()} makes {self.cuisine_type.title()} food!")

    def open_restaurant(self):                  #Opening the Restaurant
        print(f"{self.name.title()} is open!")
        print("\n")

# Working with the Restaurant Class

r1 = Restaurant('senso', 'italian')             #First instance
r1.describe_restaurant()
r1.open_restaurant()

r2 = Restaurant('taco bell', 'mexican')         #Second instance
r2.describe_restaurant()
r2.open_restaurant()

r3 = Restaurant('sakura', 'japanese')           #Third instance
r3.describe_restaurant()
r3.open_restaurant()
