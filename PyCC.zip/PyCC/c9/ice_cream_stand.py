class Restaurant:
    def __init__(self, name, cuisine_type):     #Initializing the attributes
        self.name = name
        self.cuisine_type = cuisine_type

    def describe_restaurant(self):              #Restaurant Information
        print(f"The name of the restaurant is {self.name.title()}!")
        print(f"{self.name.title()} makes {self.cuisine_type.title()} food!")

    def open_restaurant(self):                  #Opening the Restaurant
        print(f"{self.name.title()} is open!")
        print("\n")

class IceCreamStand(Restaurant):
    def __init__(self, name, cuisine_type):
        super().__init__(name, cuisine_type)
        self.flavors = [
        "Vanilla",
        "Chocolate",
        "Strawberry",
        "Mint Chocolate Chip",
        "Cookie Dough",
        "Salted Caramel",
        "Pistachio",
        "Rocky Road",
        "Mango",
        "Cookies and Cream"
        ]

    def flavor_menu(self):
        for flavor in self.flavors:
            print(flavor)

r1 = IceCreamStand('ice cream land', 'ice creams')
r1.describe_restaurant()
r1.open_restaurant()
print("Menu: ")
r1.flavor_menu()