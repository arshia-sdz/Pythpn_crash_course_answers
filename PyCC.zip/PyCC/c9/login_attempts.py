class User:
    def __init__(self, first_name, last_name):  #Initializing the attributes
        self.first_name = first_name
        self.last_name = last_name
        self.login_attempts = 0

    def describe_user(self):                    #User's information
        print(f"User's First Name: {self.first_name.title()}")
        print(f"User's Last Name: {self.last_name.title()}")

    def greet_user(self):                       #Greet the user
        print(f"Greetings {self.first_name.title()} {self.last_name.title()}.\n")

    def increment_login_attempts(self):
        self.login_attempts += 1

    def reset_login_attempts(self):
        self.login_attempts = 0

# Working with User Class
my_name = User('arshia', 'sadeghzadeh')         #First instance
my_name.describe_user()
my_name.greet_user()
print(my_name.login_attempts)

my_name.increment_login_attempts()
my_name.increment_login_attempts()
my_name.increment_login_attempts()
print(my_name.login_attempts)

my_name.reset_login_attempts()
print(my_name.login_attempts)

