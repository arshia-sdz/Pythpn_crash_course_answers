# Importing the classes
from car import Car
from electric_car_2 import ElectricCar, Battery

# working with them
my_mustang = Car('ford', 'mustang', 2024)
print(my_mustang.get_descriptive_name())
my_leaf = ElectricCar('nissan', 'leaf', 2024)
print(my_leaf.get_descriptive_name())
