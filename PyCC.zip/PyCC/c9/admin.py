# 9.7
"""
class User:
    def __init__(self, first_name, last_name):  #Initializing the attributes
        self.first_name = first_name
        self.last_name = last_name

    def describe_user(self):                    #User's information
        print(f"User's First Name: {self.first_name.title()}")
        print(f"User's Last Name: {self.last_name.title()}")

    def greet_user(self):                       #Greet the user
        print(f"Greetings {self.first_name.title()} {self.last_name.title()}.\n")

class Admin(User):
    def __init__(self, first_name, last_name):
        super().__init__(first_name, last_name)
        self.privileges = [
        "Create new posts",
        "Edit existing posts",
        "Delete posts",
        "Approve comments",
        "Delete comments",
        "Manage user accounts",
        "Assign user roles",
        "Access analytics dashboard",
        "Customize site settings",
        "Moderate forums"
        ]

    def show_privileges(self):
        print(f"{self.first_name.title()} {self.last_name.title()} privileges are:")
        for privileges in self.privileges:
            print(privileges)

admin_1 = Admin('arshia', 'sadeghzadeh')
admin_1.show_privileges()
"""
# 9.8
class User:
    def __init__(self, first_name, last_name):  #Initializing the attributes
        self.first_name = first_name
        self.last_name = last_name

    def describe_user(self):                    #User's information
        print(f"User's First Name: {self.first_name.title()}")
        print(f"User's Last Name: {self.last_name.title()}")
        print("User Type = Normal")

    def greet_user(self):                       #Greet the user
        print(f"Greetings {self.first_name.title()} {self.last_name.title()}.\n")

class Privileges(User):
    def __init__(self, first_name, last_name):
        super().__init__(first_name, last_name)
        self.privileges = [
        "Create new posts",
        "Edit existing posts",
        "Delete posts",
        "Approve comments",
        "Delete comments",
        "Manage user accounts",
        "Assign user roles",
        "Access analytics dashboard",
        "Customize site settings",
        "Moderate forums"
        ]

    def show_privileges(self):
        print(f"{self.first_name.title()} {self.last_name.title()} privileges are:")
        for privileges in self.privileges:
            print(privileges)

class Admin(Privileges):
    def __init__(self, first_name, last_name):
        super().__init__(first_name, last_name)

    def describe_user(self):                    #User's information
        print(f"User's First Name: {self.first_name.title()}")
        print(f"User's Last Name: {self.last_name.title()}")
        print("User Type = Admin")

