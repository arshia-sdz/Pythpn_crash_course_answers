car = 'porsche'

if car == 'bmw':
    print("I guessed it was a BMW!")
    print('Result:', car == 'bmw') 
else:
    print("It is not BMW, the I don't know what is the car!")
    print('Result:', car == 'bmw')
    print('Answer:', car)

print('\n') 

drink = 'water'

if drink == 'water':
    print("I guessed it was a water!")
    print('Result:', drink == 'water') 
else:
    print("It is not water, the I don't know what is the drink!")
    print('Result:', drink == 'water')
    print('Answer:', drink)

print('\n') 

car = 'mercedes'

if car == 'porsche':
    print("I guessed it was a porsche!")
    print('Result:', car == 'porsche') 
else:
    print("It is not Porsche, the I don't know what is the car!")
    print('Result:', car == 'porsche')
    print('Answer:', car)

print('\n') 

drink = 'soda'

if drink == 'water':
    print("I guessed it was a soda!")
    print('Result:', drink == 'water') 
else:
    print("It is not BMW, the I don't know what is the drink!")
    print('Result:', drink == 'water')
    print('Answer:', drink)

print('\n') 

car = 'tank'

if car == 'porsche':
    print("I guessed it was a tank!")
    print('Result:', car == 'tank') 
else:
    print("It is not Tank, the I don't know what is the car!")
    print('Result:', car == 'tank')
    print('Answer:', car)
