favorite_fruits = ['apple', 'orange', 'banana'] 


if 'apple' in favorite_fruits:
    print('One apple a day keeps doctor away!') 
if 'orange' in favorite_fruits:
    print('Enjoyable during Winter!')
if 'banana' in favorite_fruits:
    print('Good for Muscle growth!') 
