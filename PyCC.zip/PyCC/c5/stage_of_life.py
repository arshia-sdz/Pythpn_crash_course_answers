person = 0
if person < 2:
    print('Not a Cute Baby!')
elif person >= 2 and person < 4:
    print("You are going to grow up as an ugly person!")
elif person >= 4 and person < 12:
    print("You won't have your dream job as your future job!") 
elif person >= 12 and person < 20:
    print("School is going to be a Turture house!") 
elif person >= 20 and person < 65:
    print("You are going to be Homeless forever!") 
else:
    print("You are going to die in pain and alone!") 
