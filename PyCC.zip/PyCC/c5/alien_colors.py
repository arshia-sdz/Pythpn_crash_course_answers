# Alien Colors 1
'''
alien_color = 'green'
if alien_color == 'green':
    print('You just earned 5 points!') 

if alien_color == 'red':
    print('You just erned 10 points!') 
'''

# Alien Colors 2
'''
alien_color = 'red'
if alien_color == 'green':
     print('You just earned 5 points!')
else:
     print('You just earned 10 points!')

alien_color = 'yellow'
if alien_color == 'green':
     print('You just earned 5 points!')
else:
     print('You just earned 10 points!')
'''

# Alien Colors 3
'''
alien_color = 'red' 
if alien_color == 'green':
    print('You just earned 5 points!')
elif alien_color == 'yellow':
    print('You just earned 10 points!') 
else:
    print('You just earned 15 points!') 

alien_color = 'green' 
if alien_color == 'green':
    print('You just earned 5 points!')
elif alien_color == 'yellow':
    print('You just earned 10 points!') 
else:
    print('You just earned 15 points!') 

alien_color = 'yellow' 
if alien_color == 'green':
    print('You just earned 5 points!')
elif alien_color == 'yellow':
    print('You just earned 10 points!') 
else:
    print('You just earned 15 points!') 
'''