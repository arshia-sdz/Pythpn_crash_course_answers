# 5.8 & 5.9
'''
users = ('admin' ,'john', 'margo', 'pirate707', 'kingjj89')

if users:
	for user in users:
		if user == 'admin':
			print("Welcome Back Sire, Would you like to see the status report")
		else:
			print(f"Welcome Back {user.title()}!")
else:
	print(">>> Error ...\nWe need to find some users!") 
'''

# 5.10
'''
current_users = ['arshia', 'john', 'jack', 'jones'] 
new_users = ['jack', 'jones','jame', 'jolie'] 


for new_user in new_users:
	new_user = new_user.lower()

	# Extracting elements from current_users in lower case
	for current_user in current_users:
		current_user = current_user.lower()

	if new_user in current_users:
		print('You have to type another user name!')
	else:
		print('This username is available!') 
'''

# 5.11
'''
ord_num = [value for value in range(1,10)]
for number in ord_num:
	if number == 1:
		print(f'{number}st') 
	elif number == 2:
		print(f'{number}nd')
	elif number == 3:
		print(f'{number}rd')
	else:
		print(f'{number}th') 
'''
