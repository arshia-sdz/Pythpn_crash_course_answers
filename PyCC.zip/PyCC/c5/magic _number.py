answer = 42
if answer != 42:
    print("That is not the correct answer. Please try again!")
else:
    print('Your answer is correct!') 

