cars = ['audi', 'bmw', 'subaru', 'toyota'] 

for car in cars:
    if car == 'bmw':
        print(car.upper())
    else:
        print(car.title())

print('\n')

# My Own Version
camera = ['hasselblad', 'sony', 'fujifilm', 'canon', 'imax']

for c in camera:
    if c == 'imax':
        print(c.upper()) 
    else:
        print(c.title()) 

