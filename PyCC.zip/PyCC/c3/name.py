firends = ['aditya', 'miles', 'hrant', 'morne', 'divan']
print('\n')
print(f'\t{firends[0].title()}') 
print(f'\t{firends[1].title()}') 
print(f'\t{firends[2].title()}') 
print(f'\t{firends[3].title()}') 
print(f'\t{firends[4].title()}')   
print(f'\nMy best firend at school is {firends[0].title()}!') 
print(f'My Athelete firend at school is {firends[1].title()} with his huge legs!')
print(f'My Muscular firend at school is {firends[2].title()}. He is thick as F*ck!') 
print(f'My Intersting firends at school is {firends[3].title()} and {firends[4].title()}, Which are the coolest!\n') 

fav_cars = ['frerrari', 'bugatti', 'toyota', 'lexus', 'aston martin', 'mercedes benz',
'rolls royce', 'lamborghini', 'land rover', 'porsche', 'Koenigsegg', 'mclaren'] 
print(f'My favorite Off-road SUVs are {fav_cars[2].title()} Land Cruise and {fav_cars[3].title()} GX!\n') 

