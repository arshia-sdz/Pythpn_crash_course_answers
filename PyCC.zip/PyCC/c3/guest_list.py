guest_list = ['mom', 'dad', 'brother', 'grandma', 'grandpa', 'uncle'] 
'''
print(f'\nI will invite my {guest_list[0].title()} to show I progressed in cooking!') 
print(f'\nI will invite my {guest_list[1].title()} to talk about future and get advices!') 
print(f'\nI will invite my {guest_list[2].title()} to beat him in FIFA!') 
print(f'\nI will invite my {guest_list[3].title()} to show her what happened to me all these years!') 
print(f'\nI will invite my {guest_list[4].title()} to look his face and remember how I missed him when he was not here!')
print(f'\nI will invite my {guest_list[5].title()} to play some Poker!') 
'''

pop_guest = 'grandpa' 
guest_list.remove(pop_guest)
print(f'\nUnforunately my {pop_guest} can not come because he is somewhere that he can not reach us') 


# print('Good news, I have found a new table! I want to invite more people now.')
guest_list.insert(6, 'aunts') 
guest_list[4] = 'uncles'
guest_list.insert(0, 'myself') 
guest_list.append('god') 


print(f'\nThe list has increased alot, so I will invite everyone!') 
for guest in guest_list:
	print(f'Welcome {guest}! I missed you so much!') 


print(guest_list) 
pop_guest_1 = guest_list.pop(5)
pop_guest_2 = guest_list.pop(5)
pop_guest_list = [] 
pop_guest_list.append(pop_guest)
pop_guest_list.append(pop_guest_1)
pop_guest_list.append(pop_guest_2)
print(f'Sorry {guest_list[1].title()}, {pop_guest_list[0].title()}, {pop_guest_list[1].title()} and {pop_guest_list[2].title()} could not come!') 
