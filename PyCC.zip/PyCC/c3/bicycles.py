bicycles = ['trek', 'condale', 'redline', 'specialized'] 
print(bicycles[0].title())   