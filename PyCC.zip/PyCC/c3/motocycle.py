motocycles = ['honda', 'yamaha', 'suzuki']
print(motocycles)
motocycles.append('ducati')
print(motocycles) 

cars = []
cars.append('frerrari')
cars.append('lamborghini')
cars.append('toyota')
print(cars)

cars.insert(-1, 'Porsche') 
print(cars)

del cars[3] 
print(cars)

