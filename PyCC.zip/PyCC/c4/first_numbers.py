for v in range(9):
	print(v) 

numbers = list(range(101))
print(numbers) 

