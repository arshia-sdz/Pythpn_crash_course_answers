print('\n')
players = ['charles', 'martina', 'michael', 'florence', 'eli']
print(players[0:7]) 
print(players[1:3]) 
print(players[:3])
print('\n')


print('Here is the first three members of my team:')
for x in players[:3]:
	print(x) 
print('\n')
