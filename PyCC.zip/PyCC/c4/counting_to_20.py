# Counting to Twenty
for value in range(1,21):
	print(value)


# One Million
num = [value for value in range(1,1_000_001)]
'''for value in num:
	print(value) '''


# Summing a Million
print(min(num))
print(max(num)) 
print(sum(num)) 


# Odd Numbers
odd_num = [value for value in range(1,21,2)]
print(odd_num) 
for value in odd_num:
	print(value)

#threets
ord_num = [value for value in range(3,31,3)]
print(ord_num)
for value in ord_num:
	print(value)

# Cubes
cube_num = [value**3 for value in range(1,11)]
print(cube_num) 
for value in cube_num:
	print(value) 

# Until now, I see that the list comprehension is muuch efficient for me since I know how to work with for-loop.
