pizza = ['peperoni', 'roast beef', 'mixed'] 
print('\n') 

for p in pizza:
	print(p) 
	print(f'{p.title()} is my favorite pizza!\n') 
print('I really love Pizza!\n') 
