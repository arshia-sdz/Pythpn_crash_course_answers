square_numers = [] 
for value in range(1,11):
	square_numers.append(value**2)

print(square_numers)

digits = list(range(1,11)) 
print(min(digits))
print(max(digits))
print(sum(digits))

s2 = [value**2 for value in range(1,11)] 
print(s2)  