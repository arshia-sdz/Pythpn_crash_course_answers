print('\n') 

buffet = ('french fries', 'spaghetti with meatball', 'chicken sandwitch', 
          'salad', 'burger') 

print('this buffet serves five basic foods. In the menu there is:') 
for v in buffet:
    print(f'\t' + v.title()) 

print('\n') 

# See if it gives me the expected error!
# buffet[0] = 'hot dog' 

buffet = ('french fries', 'spaghetti with meatball', 
          'chicken sandwitch', 'hot dog', 'vegan lazania')

print('The changed the foods recently. In the menu now there is:') 
for v in buffet:
    print(f'\t' + v.title()) 

print('\n')  
