animals = ['panda', 'tiger', 'owl'] 
for a in animals:
	print(a)
	print(f'A {a.title()} would not be a good pet!') 
print('All of them have eyes!') 

