# From counting_to_20.py
# Cubes

'''
cube_num = [value**3 for value in range(1,11)]
print(cube_num) 
for value in cube_num:
	print(value) 

print('\nHere is the first three cubed numbers:')
for value in cube_num[:3]:
	print(value)

print('\nHere is the three middle cubed number:')
for value in cube_num[3:6]:
	print(value) 

print('\nHere is the last three cubed numbers:')
for value in cube_num[-3:]:
	print(value) 
'''

# pizza.py
pizza = ['peperoni', 'roast beef', 'mixed'] 

friends_pizza = pizza[:] 
pizza.append('Chicago Deep-Dish')
friends_pizza.append('margharita')

print('This is the original list Pizzas:')
for value in pizza:
	print(value) 

print("\nThis is my friend's pizza:")
for value in friends_pizza:
	print(value) 


