dimensions = (200, 50)
print(dimensions[0])
print(dimensions[1]) 

# See If I can change a Tuple!
# dimensions[0] = 250
# print(dimensions

for dimension in dimensions:
	print(dimension) 
	