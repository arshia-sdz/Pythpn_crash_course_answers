magicians = ['alice', 'david', 'carolina']
for magician in magicians:
	print(f'Wow {magician.title()}, That was a nice trick!')
	print(f'{magician.title()}, I am looking forward to your next trick!') 



languages = ['french', 'dutch', 'german', 'spanish', 'arabic', 'japaense', 'mandarin']

for language in languages:
	print(f'I like to learn {language.title()}!')

