name = 'arshia sdz'
print(name.title()) 

name = 'Arshia Sdz'
print(name.lower())
print(name.upper()) 