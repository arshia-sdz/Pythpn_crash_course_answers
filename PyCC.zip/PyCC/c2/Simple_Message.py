message_1 = "I hate ISB and IB!"
print(message_1)

message_2 = "I love Sublime Text!"
print(message_2)

message_2 = "I see CAS, IA, EE and TOK useless!"
print(message_2) 
