url = 'https://www.arshia.sdz'
url = url.removeprefix('https://www.') 
print(url) 

url = 'https://www.arshia.sdz'
url = url.removesuffix('https://www.') 
print(url) 