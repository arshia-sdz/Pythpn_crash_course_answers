name = '             Arshia Sadeghzadeh            '
name = name.strip()
print(name) 