fist_name = 'arshia'
last_name = 'sadeghzadeh'
full_name = f"{fist_name} {last_name}"
print(full_name) 
print(f'Hello, {full_name.title()}') 
