quote = '''Let yourself be silently drawn by the strange pull of what you really love. It will not lead you astray.'''
person = 'Rumi'
print(f'{quote}\n\t-{person}') 
