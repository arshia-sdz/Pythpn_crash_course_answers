message = "Hello Python World!"
print(message) 

message = "Hello Python Crash Course World!"
print(message) 
