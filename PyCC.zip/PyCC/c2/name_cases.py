name = 'creativity activity service'
print(name.upper())
print(name.lower())
print(name.title()) 