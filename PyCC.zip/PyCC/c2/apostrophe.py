message = "One of the Python's strength is its diverse comunity!"
print(message) 

message = 'One of the Python's strength is its diverse comunity!''
print(message) 