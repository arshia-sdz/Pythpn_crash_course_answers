message_2_eric = "Hello Eric, May I wipe this off?"
print(message_2_eric) 