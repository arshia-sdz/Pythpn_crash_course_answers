'''
6-5. Rivers: Make a dictionary containing three major rivers and the country
each river runs through. One key-value pair might be 'nile': 'egypt'.

Use a loop to print a sentence about each river, such as The Nile runs
through Egypt.

Use a loop to print the name of each river included in the dictionary.

Use a loop to print the name of each country included in the dictionary.
'''

# This is the Dictionary that contains the information
rivers = {
	'nile': 'egypt',
	'amazon river': 'brazil',
	'mississippi': 'united states',
	'seine': 'france'
}

print('\n') 

# This for loop goes through the dictionary, first thrugh the keys , then get the value of the keys
# And then It will use the keys and values in a way I want it. Here is uses those in a sentence.
for key, value in rivers.items():
	print(f'{key.title()} is going through the {value.title()}!')


# This for loop goes through the dictionary, but only goes throught the keys 
# And then It will use the keys the a way desired
print('\nName of the Rivers:')
for key in rivers.keys():
	print(key.title()) 

# This for loop goes through the dictionary, but only goes throught the values 
# And then It will use the keys the a way desired
print('\nName of the Countries that the rivers going through:')
for value in rivers.values():
	print(value.title()) 

print('\n')

