users_0 = {
	'user name':'arshia_sdz',
	'first name': 'arshia',
	'last name': 'sadeghzadeh'
	}

for key, value in users_0.items():
	print(f"\nKey: {key.title()}")
	print(f"Value: {value}") 

''' If you write 'for key in users_0.keys()', it only works with the kids, 
	which means only one variable is assigned and that value is the key of
	the dictionary. Same thing can be said if we want to work only with the
	value in alist if we write 'for value in users_0.values()'.
	But if you want to work with both, you need to write what is writtine in
	the code 'for key, value in users_0.items()'. Remember always you assign
	a variable name for key and a variable name for value. To be more comfortable,
	just write 'for key, value in users_0.items()'.
'''



