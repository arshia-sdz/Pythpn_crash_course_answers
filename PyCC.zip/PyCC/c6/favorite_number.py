favourite_num = {
	'arshia': [8,17,24],
	'ronaldo': [7,19,36],
	'messi': [10,21,30],
	'hamilton': [42,57,66],
	'verstappen': [33,62,76]
}

for person, numbers in favourite_num.items():
	print(f"\n{person.title()}'s favorites numbers:")
	for number in numbers:
		print(number)

"""
# Explained Version
# Creating a dictionary to store each person's favorite numbers
favourite_num = {
    'arshia': [8, 17, 24],
    'ronaldo': [7, 19, 36],
    'messi': [10, 21, 30],
    'hamilton': [42, 57, 66],
    'verstappen': [33, 62, 76]
    # Each key (e.g., 'arshia') represents a person, and the value is a list of their favorite numbers.
}

# Looping through the dictionary to print each person's favorite numbers
for person, numbers in favourite_num.items():
    # 'person' is the key (person's name), and 'numbers' is the list of their favorite numbers.

    print(f"\n{person.title()}'s favorite numbers:")
    # Prints the person's name with a message, capitalized using .title() to make it more readable.
    # '\n' adds a newline before each person's output for clearer separation.

    for number in numbers:
        # This nested loop goes through each number in the list of favorite numbers for the current person.
        
        print(number)
        # Prints each number in the person's list on a new line.
"""
