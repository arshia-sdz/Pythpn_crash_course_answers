alien_0 = {'color': 'green', 'speed': 'slow'}

# To check if the it gives the error!
# print(alien_0['points'])

point_value = alien_0.get('points', 'No point value assigned.')
print(point_value)

print(alien_0)



