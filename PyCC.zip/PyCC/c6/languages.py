'''
Polling: Use the code in favorite_languages.py (page 96).

Make a list of people who should take the favorite languages poll. Include
some names that are already in the dictionary and some that are not.

Loop through the list of people who should take the poll. If they have
already taken the poll, print a message thanking them for responding.
If they have not yet taken the poll, print a message inviting them to take
the poll.
'''

# This is the Dictionary that contains the information
favorite_languages = {
	'jen': 'python',
	'sarah': 'c',
	'edward': 'rust',
	'phil': 'python',
}

print('\n')

'''
for name, language in favorite_languages.items():
	print(f"{name.title()}'s favorite language is {language.title()}!") 
'''

'''
for name in favorite_languages.keys():
	print(name.title())
'''

'''
# The same output as the top for-loop
for name in favorite_languages:
	print(name.title())
'''

# This is the for loop that goes throught the dictionary,identify the person and write its favourite language!
print("The following languages have been mentioned:")
for language in set(favorite_languages.values()):
	print(language.title())

# This code goes throught the list, find the key which in this case is sarah, and then extract the value 
# And then It will use it in the desired way
print(f"Sarah's favourite language is {favorite_languages['sarah'].title()}!")

print('\n')

''' If you write 'for key in users_0.keys()', it only works with the kids, 
	which means only one variable is assigned and that value is the key of
	the dictionary. Same thing can be said if we want to work only with the
	value in alist if we write 'for value in users_0.values()'.
	But if you want to work with both, you need to write what is writtine in
	the code 'for key, value in users_0.items()'. Remember always you assign
	a variable name for key and a variable name for value. To be more comfortable,
	just write 'for key, value in users_0.items()'.
'''


