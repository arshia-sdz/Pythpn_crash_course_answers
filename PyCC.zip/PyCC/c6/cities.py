
cities = {
	'barcelona': {
	'country': 'spain',
	'population': 1.62,
	'fact': 
	'It is the only City awarded the Royal Gold Medal for Architecture Since 1848'
	},

	'paris': {
	'country': 'france',
	'population': 2.10,
	'fact': 
	'The Love Lock Tradition'
	},

	'rio de janeiro': {
	'country': 'brazil',
	'population': 13.8,
	'fact': 
	'The city got its name from a river that is actually a bay'
	}
}

for city, information in cities.items():
	country = information['country'] 
	population = information['population']
	fact = information['fact']
	print(f"\nCity: {city.title()}"
		f"\nCountry: {country.title()}"
		f"\nPopulation: {population} million people"
		f"\nFun Fact: {fact}!"
		)


"""
# Explained Version
# Creating a dictionary to store information about various cities
cities = {
    'barcelona': {
        'country': 'spain',
        'population': 1.62,
        'fact': 
        'It is the only City awarded the Royal Gold Medal for Architecture Since 1848'
    },

    'paris': {
        'country': 'france',
        'population': 2.10,
        'fact': 
        'The Love Lock Tradition'
    },

    'rio de janeiro': {
        'country': 'brazil',
        'population': 13.8,
        'fact': 
        'The city got its name from a river that is actually a bay'
    }
    # Each key (like 'barcelona') represents a city, and its value is another dictionary containing details
    # such as country, population (in millions), and a fun fact about the city.
}

# Looping through the cities dictionary to print each city's information
for city, information in cities.items():
    # 'city' is the key (city name), and 'information' is the dictionary containing the city's details.

    country = information['country'] 
    # Retrieves the name of the country where the city is located.

    population = information['population']
    # Retrieves the population of the city (in millions).

    fact = information['fact']
    # Retrieves a fun fact about the city.

    # Printing the city's information in a formatted way
    print(f"\nCity: {city.title()}"
        f"\nCountry: {country.title()}"
        f"\nPopulation: {population} million people"
        f"\nFun Fact: {fact}!"
    )
    # The print statement displays the city's name, country, population, and fun fact.
    # .title() is used to capitalize the first letter of each word for better readability.
    # The population is followed by "million people" to specify the units.
    # '\n' before the city name ensures each city's output starts on a new line for clarity.
"""

