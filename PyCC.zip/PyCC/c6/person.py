# 6.1
'''
person = {
	'first name': 'arshia',
	'last name': 'sadeghzadeh',
	'city': 'breda',
	'age': 17
}


first_nme = person.get('first name').title() 
last_name = person.get('last name').title() 
city = person.get('city').title() 
age = person.get('age')
gender = person.get('gender', 'male')


print(
	f'{first_nme} {last_name} is a {age} year old {gender} from {city}!'
)


# 6.2
favourite_num = {
	'arshia': 8,
	'ronaldo': 7,
	'messi': 10,
	'hamilton': 42,
	'verstappen': 33
}


# How I can loop threw the dictionary without getting the values of each part
# Looping once to print each person's favorite number
for key, value in favourite_num.items():
	print(f"{key.title()}'s favourite number is {value}!")

# 6.3
'''
glossary = {
	'append': 'add an element at the end of the list',
	'sort': 'sort the list',
	'insert': 'add an element at the specified position', 
	'remove': 'remove the first item with the specified value',
	'reverse': 'reverse the order of the list'
}

# Easy and efficient way
for key, value in glossary.items():
	print(f"{key.title()} is used to {value}!\n")
'''
'''
# wrong way
'''
keys = []
for key in glossary.keys():
	keys.append(key)

values = []
for value in glossary.values():
	values.append(value) 

for value, key in values, keys:
	print(f"{key.title()} is used to {value}!")
'''


