# Cleaning
print('\n')

# Empty List
people = []

person_0 = {
	'first name': 'arshia',
	'last name': 'sadeghzadeh',
	'city': 'etten-leur',
	'age': 17
}

person_1 = {
	'first name': 'aditya',
	'last name': 'kulkarani',
	'city': 'breda',
	'age': 18
}

person_2 = {
	'first name': 'divan', 
	'last name': 'jonker',
	'city': 'cape town',
	'age': 19
}

# adding people into the list
people.append(person_0)
people.append(person_1)
people.append(person_2)

# Checking if they are in the list
'''
for person in people:
	print(person)
'''

# Looping through the information
for person in people:
	first_name = person['first name']
	last_name = person['last name']
	full_name = first_name + ' ' + last_name
	age = person['age']
	city = person['city']
	print(f'{full_name.title()} has {age} years old and lives in {city.title()}!')

# Cleaning
print('\n')


"""
# Explained version of the programm
# Cleaning
print('\n')
# Prints a newline to help organize output and separate it from any previous text printed in the terminal.

# Empty List
people = []
# Creates an empty list called 'people' where we will store information about different individuals.

# Creating dictionaries for each person
person_0 = {
    'first name': 'arshia',
    'last name': 'sadeghzadeh',
    'city': 'etten-leur',
    'age': 17
}
# 'person_0' is a dictionary containing details about the person, including their first name, last name, city, and age.
# Each key (e.g., 'first name') corresponds to a value (e.g., 'arshia').

person_1 = {
    'first name': 'aditya',
    'last name': 'kulkarani',
    'city': 'breda',
    'age': 18
}
# 'person_1' is another dictionary with similar information as 'person_0'.

person_2 = {
    'first name': 'divan', 
    'last name': 'jonker',
    'city': 'cape town',
    'age': 19
}
# 'person_2' follows the same structure, allowing us to store information for a third individual.

# Adding people into the list
people.append(person_0)
people.append(person_1)
people.append(person_2)
# The 'append' method adds each person's dictionary to the 'people' list.
# Now, 'people' is a list containing three dictionaries, each representing one person.

# Optional Check (commented out)
'''
for person in people:
    print(person)
'''
# This loop is currently commented out. If activated, it would print each dictionary in the 'people' list,
# which can be useful for checking if the data was added correctly.

# Looping through the information
for person in people:
    first_name = person['first name']
    last_name = person['last name']
    full_name = first_name + ' ' + last_name
    age = person['age']
    city = person['city']
    print(f'{full_name.title()} has {age} years old and lives in {city.title()}!')
# This loop goes through each dictionary in 'people'.
# 'first_name' and 'last_name' extract names from the dictionary to form 'full_name'.
# 'age' and 'city' extract the person's age and city.
# The 'print' statement displays a message with the full name, age, and city, formatted for readability using '.title()' 
# (which capitalizes each word's first letter in 'full_name' and 'city').

# Cleaning
print('\n')
# Another newline is printed at the end for spacing in the output.
"""
