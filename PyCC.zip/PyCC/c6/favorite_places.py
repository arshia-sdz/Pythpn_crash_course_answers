
favorite_place = {
	'ali': {
		'city': 'barcelona',
		'country': 'spain',
		'language': 'spanish',
		'currency': 'euro',
	},

	'jake': {
		'city': 'Rio de Janeiro',
		'country': 'brazil',
		'language': 'portuguese',
		'currency': 'real'
	},

	'jordan': {
	'city': 'tokyo',
	'country': 'japan',
	'language': 'japanese',
	'currency': 'yen'
	}
}


for person, information in favorite_place.items():
	country = information['country']
	city = information['city']
	language = information['language']
	currency = information['currency']
	friend = person
	print(f"{friend.title()} favorite city is {city.title()}.\n"
		f"{city.title()} is located in {country.title()}.\n"
		f"Last time {friend.title()} went there used {currency.title()}!\n"
		)

"""
# Explained Version
# Creating a dictionary to store information about each person's favorite place
favorite_place = {

    'ali': {
        'city': 'barcelona',
        'country': 'spain',
        'language': 'spanish',
        'currency': 'euro',
    },
    # Each key (like 'ali') represents a person, and the value is a dictionary containing
    # information about their favorite place, such as city, country, language, and currency.

    'jake': {
        'city': 'Rio de Janeiro',
        'country': 'brazil',
        'language': 'portuguese',
        'currency': 'real'
    },

    'jordan': {
        'city': 'tokyo',
        'country': 'japan',
        'language': 'japanese',
        'currency': 'yen'
    }
    # Each person's dictionary has the same structure, storing details about their favorite place.
}

# Looping through the favorite_place dictionary to print each person's favorite place details
for person, information in favorite_place.items():
    country = information['country']
    # 'country' retrieves the name of the country from the person's information.

    city = information['city']
    # 'city' retrieves the name of the city from the person's information.

    language = information['language']
    # 'language' retrieves the language spoken in the person's favorite place.

    currency = information['currency']
    # 'currency' retrieves the type of currency used in the person's favorite place.

    friend = person
    # 'friend' is set to the key (person's name) to use it in the output.

    # Printing a personalized message for each person about their favorite place
    print(f"{friend.title()} favorite city is {city.title()}.\n"
        f"{city.title()} is located in {country.title()}.\n"
        f"Last time {friend.title()} went there, they used {currency.title()}!\n"
    )
    # This 'print' statement displays information in a readable format:
    # 1. It shows the person's favorite city and its location.
    # 2. It mentions the currency used there, all formatted with .title() to capitalize the first letter of each word.
    # 3. '\n' adds a newline between each sentence to make the output clearer.
"""
