pets = {

	'animal_0': {
		'kind': 'dog',
		'name': 'jack',
		'owner': 'jeffty', 
	},

	'animal_1': {
		'kind': 'horse',
		'name': 'shire', 
		'owner': 'arshia'
	},

	'animal_2': {
		'kind': 'owl',
		'name': 'patty',
		'owner': 'marry'
	},

	'animal_3': {
		'kind': 'fox',
		'name': 'micky',
		'owner': 'john'
	},

	'animal_4': {
		'kind': 'cat',
		'name': 'jerry',
		'owner': 'margo'
	},

	'animal_5': {
		'kind': 'eagle',
		'name': 'dora',
		'owner': 'nikolas'
	},

	'animal_6': {
		'kind': 'panda',
		'name': 'ali ghool',
		'owner': 'mohammed'
	},

	'animal_7': {
		'kind': 'hamster',
		'name': 'potato',
		'owner': 'james'
	}

}

for animal, information in pets.items():
	animal_kind = information['kind']
	animal_name = information['name']
	owner_name = information['owner']

	print(f'Owner: {owner_name.title()}\n'
		f"Animal's kind: {animal_kind.title()}\n"
		f"Animal's name: {animal_name.title()}\n"
	)

"""
# Explained Version
# Creating a dictionary to store information about different pets
pets = {

    'animal_0': {
        'kind': 'dog',
        'name': 'jack',
        'owner': 'jeffty', 
    },
    # Each key (e.g., 'animal_0') represents a unique pet, with details stored as another dictionary.
    # This inner dictionary contains keys for 'kind', 'name', and 'owner', representing the type of animal, 
    # the animal’s name, and the owner's name.

    'animal_1': {
        'kind': 'horse',
        'name': 'shire', 
        'owner': 'arshia'
    },

    'animal_2': {
        'kind': 'owl',
        'name': 'patty',
        'owner': 'marry'
    },

    'animal_3': {
        'kind': 'fox',
        'name': 'micky',
        'owner': 'john'
    },

    'animal_4': {
        'kind': 'cat',
        'name': 'jerry',
        'owner': 'margo'
    },

    'animal_5': {
        'kind': 'eagle',
        'name': 'dora',
        'owner': 'nikolas'
    },

    'animal_6': {
        'kind': 'panda',
        'name': 'ali ghool',
        'owner': 'mohammed'
    },

    'animal_7': {
        'kind': 'hamster',
        'name': 'potato',
        'owner': 'james'
    }
    # Each 'animal_X' entry follows the same structure, allowing us to store details for various pets.
}

# Looping through the pets dictionary to print each pet's details
for animal, information in pets.items():
    animal_kind = information['kind']
    # 'animal_kind' retrieves the type of animal (e.g., 'dog', 'horse') from the inner dictionary.
    
    animal_name = information['name']
    # 'animal_name' retrieves the name of the animal.
    
    owner_name = information['owner']
    # 'owner_name' retrieves the name of the animal’s owner.

    # Printing the information in a formatted way
    print(f'Owner: {owner_name.title()}\n'
        f"Animal's kind: {animal_kind.title()}\n"
        f"Animal's name: {animal_name.title()}\n"
    )
    # 'print' displays each pet's owner, type, and name.
    # '.title()' is used to capitalize the first letter of each word for better readability.
    # '\n' adds a newline after each printed statement, making the output clearer and easier to read.
"""

