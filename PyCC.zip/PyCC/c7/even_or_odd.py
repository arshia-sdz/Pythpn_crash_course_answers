number = input("Enter you number, I'll let you know whether it's odd or even.\n")
number = int(number)

if number % 2 == 0:
	print(f"\nThe number {number} is even!")
else:
	print("\nThe number is odd!")
