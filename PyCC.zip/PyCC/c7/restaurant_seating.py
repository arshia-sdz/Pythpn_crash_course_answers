status = input("How many people are seating here?\n")
status = int(status)
if status <= 8:
	print("please seat on that free spot.")
else:
	print("You need to wait for the table!")