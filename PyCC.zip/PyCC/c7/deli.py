'''
# 7.8
# The list of Sandwiches
sandwich_orders = ['chicken', 
                   'roast beef', 
                   'ham', 
                   'grilled chicken',
                   'egg',
                   'shrimp',
                   'fish',
                   'grilled cheese',
                   ]

finished_sandwiches = []

# Looping through the sandwitches
# Transfering sandwitch_orders to finished_sandwitches
while sandwich_orders:
    sandwich = sandwich_orders.pop()
    print(f"Making {sandwich} sancdwitch!")
    finished_sandwiches.append(sandwich)

# Showing the sandwitches that is ready 
# (transfered from sandwitch_orders to finished_sandwitches)
print("\nThe following sandwitches are ready:")
for x in finished_sandwiches:
    print(f"\t{x}")
'''


#7.9
# The list of Sandwiches
sandwich_orders = ['chicken',
                   'roast beef',
                   'pastrami',
                   'ham',
                   'grilled chicken',
                   'egg',
                   'pastrami',
                   'shrimp',
                   'fish',
                   'grilled cheese',
                   'pastrami'
                   ]

finished_sandwiches = []

# All the Pastramies are finished
print("All of our Pastramies are finished unfortunatly!")
while 'pastrami' in sandwich_orders:
    sandwich_orders.remove('pastrami')

# Looping through the sandwitches
# Transfering sandwitch_orders to finished_sandwitches
while sandwich_orders:
    sandwich = sandwich_orders.pop()
    print(f"Making {sandwich} sancdwitch!")
    finished_sandwiches.append(sandwich)

# Showing the sandwitches that is ready 
# (transfered from sandwitch_orders to finished_sandwitches)
print("\nThe following sandwitches is read:")
for x in finished_sandwiches:
    print(f"\t{x}")
