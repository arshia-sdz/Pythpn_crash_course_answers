prompt = '\nPlease say what toppings you want in your pizza!'
prompt += "\nIf you wan to submit your order type 'submit'.\t"


while True:
    ingridient = input(prompt)
    if ingridient == 'submit':
        print('\nYour Order is ready!')
        break
    else:
        print(f"Adding {ingridient} to your pizza!")
        continue
