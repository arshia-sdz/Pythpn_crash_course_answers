number = input("Write your number and I say wheather it is multiple of 10 or not!\n")
number = int(number)

if number % 10 == 0:
	print("Your number is an multiple of 10!")
else:
	print("Your name is not a multiple of 10!")
