'''
# A simple way to do that!
name = input("Please enter your name: ")
print(f"Hello {name.title()}.")
'''


prompt = "If you share your name, we can personalize the messages you can see."
prompt += "\nWhat is your first name?\n"

name = input(prompt)
print(f"\nHello, {name.title()}!")
