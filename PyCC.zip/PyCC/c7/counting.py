'''
current_number = 1
while current_number <= 370:
	print(current_number)
	current_number = current_number + 1
'''

'''
# Counting the Odd Numbers.
current_number = 0
while current_number < 10:
	current_number += 1
	if current_number % 2 == 0:
		continue
	print(current_number)
'''

'''
x = 1
while x <= 5:
	print(x)
	x += 1
'''
	
'''
# This loop runs forever!
x = 1
while x <= 5:
	print(x)
'''
