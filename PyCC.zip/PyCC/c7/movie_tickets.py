
# 7.6
# What if They are multiple persons?!
prompt = '\nToday we are going to cast Openheimer on Malcom Imax Cinema.'
prompt += "\nAfter you finish purchasing your ticket(s), enter 'submit' and the total price will apear!"
prompt += '\nUnder 3 is for free, between 3 to 12 is 12$ and above 12 is 15$.'

print(prompt)
total_price = 0
while True:
    age = input("Age: ")
    if age == 'submit':
        break
    age = int(age)

    if age < 0:     # To make sure they don't put any negative number!
        print("Enter a proper age number!")
        continue

    elif age < 3: 
        total_price = total_price + 0
        continue

    elif 3 < age < 12:
        total_price = total_price + 12
        continue

    else:
        total_price = total_price + 15
        continue

print(f"The total price is {total_price}")


'''
# 7.5
prompt = '\nToday we are going to cast Openheimer on Malcom Imax Cinema'
prompt += 'After you finish entering your age, enter submit to quit the program!'
prompt += '\n>>> '

while True:
    tickets = input(prompt)
    age = int(tickets)

    if age < 0:     # To make sure they don't put any negative number!
        print("Enter a proper age number!")
        continue

    elif 0 < age < 3: 
        print("Cost: Free\nBut please be carefull so he/she doesn't make any sound")
        break

    elif 3 < age < 12:
        print("Cost: 10$")
        break

    else:          #For all other ages above 12 years old! 
        print("Cost: 15$")
        break
'''