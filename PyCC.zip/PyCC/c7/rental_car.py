car = input("What brand is in your mind to look?\n")
print(f"Let's see if we can find {car.title()}!")
