responces = {}

# Set a flag to indicate that polling is active.
polling_activities = True

while polling_activities:
    # Asking for the name of user and user's dream vocation
    name = input("\nWhat is your name? ")
    vocation = input("If you could visit one place, where would it be? ")

    # Stores the items in dictionary
    responces[name] = vocation

    # Find out if anyone else is going to take the poll.
    repeat = input("Would you like to let another person respond? (yes/ no) \n")

    if repeat == 'no':
        polling_activities = False

#The final results
print("\n--- Poll Results ---")
for x, y in responces.items():
    print(f"{x} would like to go to {y}.")
