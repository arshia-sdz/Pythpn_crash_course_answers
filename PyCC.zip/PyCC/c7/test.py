import time
print(time.asctime())