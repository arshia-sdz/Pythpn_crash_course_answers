from city_functions import location

def test_city_country_function():
	formatted_location = location('chile', 'santiago')
	assert formatted_location == 'Santiago, Chile'

def test_city_country_population_function():
	formatted_location_population = location('chile', 'santiago', 5000000)
	assert formatted_location_population == 'Santiago, Chile, Population: 5000000'
