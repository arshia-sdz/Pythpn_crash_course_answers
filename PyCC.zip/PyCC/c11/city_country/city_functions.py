def location(country, city, population = ''):

	if population:
		formatted_city = f"{city}, {country}, population: {population}"
		return formatted_city.title()

	else:
		formatted_city = f"{city}, {country}"
		return formatted_city.title()
